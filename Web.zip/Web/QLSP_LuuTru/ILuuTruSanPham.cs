﻿using QLSP_Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLSP_LuuTru
{
    public interface ILuuTruSanPham
    {
        void LuuSanPham(SanPham s);
        List<SanPham> DocDanhSach();
        void LuuDanhSach(List<SanPham> ds);
        SanPham TimSanPhamTheoTen(string ten);
        void XoaSanPham(string ten);
    }
}
