﻿using QLSP_Entity;
using System.Text.Json.Serialization;
using Newtonsoft.Json;

namespace QLSP_LuuTru
{
    public class LuuTruSanPham:ILuuTruSanPham
    {
        private const string FilePath = "E:\\MiNoA\\NoA\\Noa_CareerPath\\KhoaHocTuNhien\\5_HK1_2024_2025\\02_PPLTHDT\\sanpham.json";
        public void LuuSanPham(SanPham s)
        {
            var ds = DocDanhSach();
            int maxId = 0;
            foreach (var item in ds)
            {
                if(item.MaSp > maxId)
                {
                    maxId = item.MaSp;
                }
            }
            s.MaSp = maxId + 1;
            ds.Add(s);
            LuuDanhSach(ds);
        }

        public List<SanPham> DocDanhSach()
        {
            StreamReader file = new StreamReader(FilePath);
            string jsonString = file.ReadToEnd();
            var ds = JsonConvert.DeserializeObject<List<SanPham>>(jsonString);
            file.Close();
            return ds;
        }

        public void LuuDanhSach(List<SanPham> ds)
        {
            string jsonString = JsonConvert.SerializeObject(ds);
            StreamWriter file = new StreamWriter(FilePath);
            file.Write(jsonString);
            file.Close();
        }
        public SanPham TimSanPhamTheoTen(string ten)
        {
            var ds = DocDanhSach();
            foreach (SanPham s in ds)
            {
                if (s.TenSP == ten)
                {
                    return s;
                }
            }
            return null;
        }

        public void XoaSanPham(string ten)
        {
            var ds = DocDanhSach();
            var dsMoi = new List<SanPham>();            
            foreach (SanPham s in ds)
            {
                if (s.TenSP != ten)
                {
                    dsMoi.Add(s);
                }
                LuuDanhSach(dsMoi);
            }
        }
    }
}