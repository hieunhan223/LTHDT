﻿using QLSP_Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLSP_XuLyNghiepVu
{       
    public interface IXuLySanPham
    {
        void ThemSanPham(SanPham s);
        List<SanPham> DocDanhSach(string tukhoa="");
        SanPham DocSanPham(int MaSP);
        void SuaSanPham(SanPham sp);
        void XoaSanPham(SanPham sp);
    }    
}
