﻿using QLSP_LuuTru;
using QLSP_Entity;

namespace QLSP_XuLyNghiepVu
{
    public class XuLySanPham : IXuLySanPham
    {
        private ILuuTruSanPham _luuTruSanPham;
        public XuLySanPham(ILuuTruSanPham luuTruSanPham)
        {
            _luuTruSanPham = luuTruSanPham;
        }

        public void ThemSanPham(SanPham s)
        {
            //San pham phai co ten duy nhat
            SanPham sp = _luuTruSanPham.TimSanPhamTheoTen(s.TenSP);
            if (sp!= null)
            {
                throw new Exception("Ten san pham da ton tai");
            }
            _luuTruSanPham.LuuSanPham(s);
        }
        public List<SanPham> DocDanhSach(string tukhoa = "")
        {
            var dsSanPham = _luuTruSanPham.DocDanhSach();
            var ketQua = new List<SanPham>();
            foreach (var sp in dsSanPham)
            {
                if (sp.TenSP.Contains(tukhoa))
                {
                    ketQua.Add(sp);
                }                
            }
            return ketQua;
        }

        public SanPham DocSanPham (int MaSP)
        {
            var dsSanPham = _luuTruSanPham.DocDanhSach();
            
            foreach (var sp in dsSanPham)
            {
                if (sp.MaSp == MaSP)
                {
                    return sp;
                }
            }
            return null;
        }

        public void SuaSanPham(SanPham sp)
        {
            var dsSanPham = _luuTruSanPham.DocDanhSach();
            for(int i=0; i<dsSanPham.Count;i++)
            {
                if (dsSanPham[i].MaSp == sp.MaSp)
                {
                    dsSanPham[i] = sp;
                }
            }
            _luuTruSanPham.LuuDanhSach(dsSanPham);
        }      
        public void XoaSanPham(SanPham sanPham)
        {             
            _luuTruSanPham.XoaSanPham(sanPham.TenSP);
        }
    }
}