using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using QLSP_Entity;
using QLSP_XuLyNghiepVu;

namespace LTHDT_2024_07_Web.Pages
{
    public class MH_ThemSanPhamModel : PageModel
    {

        [BindProperty]
        public string TenSP { get; set; }
        [BindProperty]
        public int HSD { get; set; }
        [BindProperty]
        public string CongtySX { get; set; }
        [BindProperty]
        public int NamSX { get; set; }
        [BindProperty]
        public string loaiHang { get; set; }

        public string Chuoi { get; set; } = string.Empty;
        private IXuLySanPham _xuLySanPham;

        public MH_ThemSanPhamModel():base()
        {
            _xuLySanPham = ObjectCreator.TaoDoiTuongXuLySanPham();
        }
        public void OnGet()
        {
            Chuoi = "Vui long nhap thong tin san pham";
        }
        public void OnPost()
        {
            try
            {
                SanPham s = new SanPham(TenSP,HSD,CongtySX,NamSX,loaiHang);
                _xuLySanPham.ThemSanPham(s);
                Response.Redirect("MH_DanhSachSanPham");
            }
            catch (Exception ex)
            {
                Chuoi= ex.Message;  
            }
        }
    }
}
