using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using QLSP_Entity;
using QLSP_XuLyNghiepVu;

namespace LTHDT_2024_07_Web.Pages
{
    public class MH_DanhSachSanPhamModel : PageModel
    {
        public List<SanPham> DanhSachSanPham { get; set; }
        private IXuLySanPham _xuLySanPham;
        [BindProperty]
        public string TuKhoa { get; set; }

        public string Chuoi = string.Empty;
        public MH_DanhSachSanPhamModel()
        {
            _xuLySanPham = ObjectCreator.TaoDoiTuongXuLySanPham();
        }
        public void OnGet()
        {
            DanhSachSanPham = _xuLySanPham.DocDanhSach();
        }
        public void OnPost()
        {
            try
            {
                DanhSachSanPham = _xuLySanPham.DocDanhSach(TuKhoa);
            }
            catch (Exception ex)
            {
                Chuoi = ex.Message;
            }
        }
    }
}
