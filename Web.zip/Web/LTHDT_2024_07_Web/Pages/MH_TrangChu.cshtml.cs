using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace LTHDT_2024_07_Web.Pages
{
    public class MH_TrangChuModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
