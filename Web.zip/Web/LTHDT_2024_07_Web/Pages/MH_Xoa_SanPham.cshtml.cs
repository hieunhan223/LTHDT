using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using QLSP_Entity;
using QLSP_XuLyNghiepVu;

namespace LTHDT_2024_07_Web.Pages
{
    public class MH_Xoa_SanPhamModel : PageModel
    {       
        public string Chuoi { get; set; } = string.Empty;

        private IXuLySanPham _xuLySanPham;

        public void OnGet()
        {
            Chuoi = "Ban co muon xoa san pham khong";
        }

        public void OnPost()
        {
            try
            {                
                //_xuLySanPham.XoaSanPham(s);
            }
            catch (Exception ex)
            {
                Chuoi = ex.Message;
            }
        }

    }
}
