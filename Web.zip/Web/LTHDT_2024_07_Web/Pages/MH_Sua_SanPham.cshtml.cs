using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using QLSP_Entity;
using QLSP_XuLyNghiepVu;

namespace LTHDT_2024_07_Web.Pages
{
    public class MH_Sua_SanPhamModel : PageModel
    {
        private IXuLySanPham _xuLySanPham;
        [BindProperty]
        public string TenSP { get; set; }
        [BindProperty]
        public int HSD { get; set; }
        [BindProperty]
        public string CongtySX { get; set; }
        [BindProperty]
        public int NamSX { get; set; }
        [BindProperty]
        public string loaiHang { get; set; }
        public  SanPham SanPham { get; set; }

        [BindProperty(SupportsGet = true)]
        public int MaSp { get; set; }
        public string Chuoi = string.Empty;
        public MH_Sua_SanPhamModel()
        {
            _xuLySanPham = ObjectCreator.TaoDoiTuongXuLySanPham();
        }
        public void OnGet()
        {
            if (MaSp == 0)
            {
                Chuoi = "Ma san pham khong hop le";
                return;
            }
            SanPham = _xuLySanPham.DocSanPham(MaSp);
            if (SanPham == null)
            {
                Chuoi = "Khong tim thay san pham";
            }            
        }

        public void OnPost()
        {
            try
            {
                if (MaSp == 0)
                {
                    Chuoi = "Ma san pham khong hop le";
                    return;
                }
                SanPham = _xuLySanPham.DocSanPham(MaSp);
                if (SanPham == null)
                {
                    Chuoi = "Khong tim thay san pham";
                }
                else
                {
                    SanPham.MaSp = MaSp;
                    SanPham.TenSP = TenSP;
                    SanPham.HSD = HSD;
                    SanPham.CongtySX = CongtySX;
                    SanPham.NamSX = NamSX;
                    SanPham.loaiHang = loaiHang;
                    _xuLySanPham.SuaSanPham(SanPham);
                    Response.Redirect("/MH_DanhSachSanPham");
                }
            }
            catch (Exception ex)
            {
                Chuoi = ex.Message;
            }
        }
    }
}
