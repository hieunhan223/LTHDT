﻿using QLSP_LuuTru;
using QLSP_XuLyNghiepVu;

namespace LTHDT_2024_07_Web
{
    public class ObjectCreator
    {
        public static IXuLySanPham TaoDoiTuongXuLySanPham()
        {
            ILuuTruSanPham luuTru = new LuuTruSanPham();
            return new XuLySanPham(luuTru);
        }
    }
}
