﻿namespace QLSP_Entity
{
    public class SanPham
    {
        public int MaSp { get; set; }
        public string TenSP { get; set; }
        public int HSD {  get; set; }
        public string CongtySX {  get; set; }
        public int NamSX    { get; set; }
        public string loaiHang {  get; set; }      
        
        public SanPham(string TenSP, int HSD, string CongtySX, int NamSX, string loaiHang)
        {
            if (string.IsNullOrEmpty(TenSP))
            {
                throw new Exception("Ten san pham khong hop le");
            }      
            this.MaSp = MaSp;
            this.TenSP = TenSP;   
            this.HSD = HSD;
            this.CongtySX = CongtySX;
            this.NamSX = NamSX; 
            this.loaiHang = loaiHang;
        }
    }
}